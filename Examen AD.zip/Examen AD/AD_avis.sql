-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:8889
-- Tiempo de generación: 09-12-2021 a las 21:34:37
-- Versión del servidor: 5.7.32
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `AD_avis`
--
CREATE DATABASE IF NOT EXISTS `AD_avis` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `AD_avis`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coches`
--

CREATE TABLE `coches` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `puertas` int(11) NOT NULL,
  `asientos` int(11) NOT NULL,
  `tipo_conduccion` enum('manual','automático') NOT NULL,
  `precio_dia` double NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `coches`
--

INSERT INTO `coches` (`id`, `tipo`, `descripcion`, `puertas`, `asientos`, `tipo_conduccion`, `precio_dia`, `updated_at`, `created_at`) VALUES
(1, 'Pequeño/s', 'Por ejemplo Fiat Panda', 3, 4, 'manual', 154.9, '2021-12-04 14:35:36', '2021-12-04 14:35:36'),
(2, ' Pequeño/s', 'Por ejemplo Seat Ibiza ', 5, 5, 'manual', 206.49, '2021-12-04 14:37:26', '2021-12-04 14:37:26'),
(3, ' Mediano/s', 'Por ejemplo Seat Leon ', 5, 5, 'manual', 275.34, '2021-12-04 14:37:26', '2021-12-04 14:37:26'),
(4, ' Mediano/s', 'Por ejemplo Opel Crossland X ', 5, 5, 'manual', 400.01, '2021-12-04 14:39:29', '2021-12-04 14:39:29'),
(5, 'Monovolúmen', 'Por ejemplo Renault Scenic (5+2 seats) ', 5, 5, 'manual', 557.84, '2021-12-04 14:39:29', '2021-12-04 14:39:29'),
(6, ' Monovolúmen', 'Por ejemplo Mercedes-Benz Vito', 5, 9, 'automático', 780.98, '2021-12-04 14:40:11', '2021-12-04 14:40:11'),
(7, ' Monovolúmen', 'Por ejemplo Mercedes-Benz V-Class ', 5, 7, 'automático', 669.4, '2021-12-04 14:40:55', '2021-12-04 14:40:55');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `extras`
--

CREATE TABLE `extras` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` double NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `extras`
--

INSERT INTO `extras` (`id`, `titulo`, `descripcion`, `precio`, `updated_at`, `created_at`) VALUES
(1, 'Conductor adicional', 'Más de un conductor: al añadir uno o más conductores al alquiler, todos podrán beneficiarse de la cobertura por daños o por robo.', 25.32, '2021-12-04 14:42:16', '2021-12-04 14:42:16'),
(2, 'Tablet para el viaje', 'Añade una tablet para el viaje y disfruta de una solución todo en uno: 1 GB diario de datos 4G; un punto Wi-Fi al que pueden conectarse hasta 5 dispositivos con servicios como el GPS y Trip Advisor; un conversor de divisas y una herramienta de traducción para más de 100 idiomas.', 46, '2021-12-04 14:43:09', '2021-12-04 14:43:09'),
(3, 'Avis GPS', 'Alquila un sistema de navegación por satélite Garmin para consultar mapas actualizados, alertas de tráfico en tiempo real y lugares de interés; además, dispondrás de navegación por audio en todos los idiomas europeos, así como en árabe, chino y ruso.', 34.5, '2021-12-04 14:43:09', '2021-12-04 14:43:09'),
(4, 'Asiento infantil', 'Añade a tu reserva la silla de seguridad para niños orientada hacia adelante.', 27.6, '2021-12-04 14:44:44', '2021-12-04 14:44:44'),
(5, 'Portaesquís', '¿Todo listo para tu próxima aventura de invierno? Añade un portaesquís a tu reserva y decide en la oficina de recogida si prefieres un portaesquí para los esquís o un portatabla para la tabla de snowboard.', 27.84, '2021-12-04 14:44:44', '2021-12-04 14:44:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `coche_id` int(11) NOT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `precio_total` double NOT NULL,
  `estado` enum('pendiente','pagado') DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `user_id`, `coche_id`, `fecha_inicio`, `fecha_fin`, `precio_total`, `estado`, `updated_at`, `created_at`) VALUES
(1, 3, 2, '2021-12-17', '2021-12-19', 456.34, 'pagado', '2021-12-04 14:46:41', '2021-12-04 14:46:41'),
(2, 3, 6, '2022-01-21', '2021-12-31', 1383.25, 'pagado', '2021-12-04 14:46:50', '2021-12-04 14:46:50'),
(3, 4, 1, '2021-12-30', '2022-01-02', 354.98, 'pendiente', '2021-12-04 14:54:31', '2021-12-04 14:54:31'),
(4, 3, 1, '1970-01-01', '1970-01-01', 433.34, 'pendiente', '1970-01-01 09:32:23', '1970-01-01 00:07:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas_extras`
--

CREATE TABLE `reservas_extras` (
  `id` int(11) NOT NULL,
  `reserva_id` int(11) NOT NULL,
  `extra_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `reservas_extras`
--

INSERT INTO `reservas_extras` (`id`, `reserva_id`, `extra_id`) VALUES
(1, 3, 3),
(2, 3, 5),
(3, 2, 5),
(4, 2, 4),
(5, 2, 3),
(6, 2, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','users') CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `rol`, `updated_at`, `created_at`) VALUES
(2, 'admin', 'admin@admin.org', '81dc9bdb52d04dc20036dbd8313ed055', 'admin', '2021-11-14 15:19:35', '2021-09-24 02:17:52'),
(3, 'Ines', 'ilarranaga@jesuitasformacion.com', '81dc9bdb52d04dc20036dbd8313ed055', 'users', '2021-11-14 15:19:39', '2021-09-24 02:25:32'),
(4, 'Ines2', 'ilarranaga2@jesuitasformacion.com', '81dc9bdb52d04dc20036dbd8313ed055', 'users', '2021-11-14 15:19:39', '2021-09-24 02:25:32');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `coches`
--
ALTER TABLE `coches`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `extras`
--
ALTER TABLE `extras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `coche_id` (`coche_id`);

--
-- Indices de la tabla `reservas_extras`
--
ALTER TABLE `reservas_extras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reserva_id` (`reserva_id`),
  ADD KEY `extra_id` (`extra_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `coches`
--
ALTER TABLE `coches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `extras`
--
ALTER TABLE `extras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `reservas_extras`
--
ALTER TABLE `reservas_extras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reservas_ibfk_1` FOREIGN KEY (`coche_id`) REFERENCES `coches` (`id`),
  ADD CONSTRAINT `reservas_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `reservas_extras`
--
ALTER TABLE `reservas_extras`
  ADD CONSTRAINT `reservas_extras_ibfk_1` FOREIGN KEY (`extra_id`) REFERENCES `extras` (`id`),
  ADD CONSTRAINT `reservas_extras_ibfk_2` FOREIGN KEY (`reserva_id`) REFERENCES `reservas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:8889
-- Tiempo de generación: 03-03-2022 a las 07:38:31
-- Versión del servidor: 5.7.32
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `AD_tienda`
--
CREATE DATABASE IF NOT EXISTS `AD_tienda` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `AD_tienda`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `titulo`, `descripcion`) VALUES
(1, 'ropa', 'Esta es la sección de ropa'),
(2, 'electrónica', 'Esta es la sección de electrónica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `estado` enum('pagado','nopagado') NOT NULL,
  `fechapedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `usuario_id`, `estado`, `fechapedido`) VALUES
(1, 1, 'pagado', '2022-02-16 09:41:04'),
(2, 2, 'nopagado', '2022-02-16 09:41:04'),
(3, 1, 'nopagado', '2022-02-16 09:41:14'),
(6, 2, 'pagado', '2022-02-16 09:41:37'),
(7, 1, 'pagado', '2022-02-16 09:41:37');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_productos`
--

CREATE TABLE `pedidos_productos` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `detalle` text NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `precio` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `titulo`, `detalle`, `categoria_id`, `precio`) VALUES
(1, 'Levi\'s kids Lvb Knit Crew Jogger Set Pantaln Deportivo, Aegean Blue, 6 Meses Bebé-Niños ', 'Un dúo lindo y cómodo para el doble de aspecto de Levi\'s. Diseño de camuflaje completo. 60% Algodón, 40% Poliéster. Lavar a máquina. \r\n', 1, 30.05),
(2, 'adidas I Bos Logo Jog Conjunto Deportivo, Bebé-Niños ', 'Felpa 70% algodón / 30% poliéster reciclado. Los productos deportivos de la marca adidas están diseñados para que disfrutes de tu deporte favorito sin preocuparte de nada más que rendir al máximo ', 1, 35),
(3, 'Lector de DNI electrónico 3.0 y 4.0 MAC INTEL ', 'Lector de dni electrónico 3 0 y 4.0 auto instalable en mac-os (de el Capitán a Big SUR -windows y linux. Diseňado en puro estilo mac, tanto en caracterịsticas tėcnicas como operativas, por chipnet ', 2, 19.3),
(4, 'PocketBook Touch Lux 5 - Libro electrónico (8 GB de Memoria, Pantalla de 15,24 cm (6\"), SMARTlight, WiFi), Color Rojo RubyRed ', 'Pantalla grande de 6 pulgadas E-Ink Carta HD que muestra 16 niveles de grises. Tipo de conectividad: Bluetooth; Tamaño de pantalla: 15.24 centimeters; Fuente de alimentación: Funciona a mano. ', 2, 128.99),
(5, 'Blackview R3 Smartwatch, Reloj Inteligente Hombre - Oxímetro de Pulso (SpO2) | Esfera de Reloj de DIY | Pulsera Actividad Inteligente Caloría | Smartwatch Mujer para Android e iOS (Versión Mejorada) ', 'Reloj mejorado, pero no será más caro!] R3 es uno de nuestros relojes más satisfactorios, Está equipado con hardware más avanzado, como sensor óptico de frecuencia cardíaca, acelerómetro y detector de oxígeno en sangre, Y tiene más de 20 funciones. Gracias al desarrollo de la ciencia y la tecnología, solo tenemos que pagar el mismo coste de compra, pero podemos conseguir relojes más avanzados. ', 2, 29.99),
(6, 'Mi titulo', 'Esto es el detalle', 2, 343.2),
(7, 'Mi titulo', 'Esto es el detalle', 2, 343.2),
(8, 'Mi titulo', 'Esto es el detalle', 2, 343.2),
(9, 'Mi titulo1', 'Esto es el detalle1', 1, 33.2),
(10, 'Mi titulo11', 'Esto es el detalle11', 1, 31.2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`) VALUES
(1, 'Ines', 'Larrañaga'),
(2, 'Mario', 'Pérez');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `pedidos_productos`
--
ALTER TABLE `pedidos_productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `pedidos_productos`
--
ALTER TABLE `pedidos_productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `pedidos_productos`
--
ALTER TABLE `pedidos_productos`
  ADD CONSTRAINT `pedidos_productos_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`),
  ADD CONSTRAINT `pedidos_productos_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

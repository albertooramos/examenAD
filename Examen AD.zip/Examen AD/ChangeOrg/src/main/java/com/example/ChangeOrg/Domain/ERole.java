package com.example.ChangeOrg.Domain;


public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}


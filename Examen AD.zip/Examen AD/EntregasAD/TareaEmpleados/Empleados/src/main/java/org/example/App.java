package org.example;

import org.example.dao.DepartmentDao;
import org.example.dao.EmployeeDao;
import org.example.models.Department;
import org.example.models.Employee;
import org.example.models.Salary;

import java.util.List;


public class App 
{
    public static void main( String[] args )
    {


        Department dep = new DepartmentDao().getDepartment("2");
        System.out.println(dep);


        List<Department> depRespuesta = (List<Department>) new DepartmentDao().listaDepartamentos();
        depRespuesta.forEach(System.out::println);


        Employee emp = new EmployeeDao().getEmployee(1);
        System.out.println(emp);

        List<Employee> empRespuesta = (List<Employee>) new EmployeeDao().listaEmpleadosDepartamento("d005");
        empRespuesta.forEach(System.out::println);

        Employee emp1 = new EmployeeDao().managerDepartamento("2");
        System.out.println(emp1);

        Boolean emp2 = new EmployeeDao().isManager("2",2);
        System.out.println(emp2);

        Employee emp3 = (Employee) new EmployeeDao().getEmployeesByTitle("Staff");
        System.out.println(emp3);

        Employee emp4 = new Employee(2, "1995-11-08", "Alberto", "Ramos", "M", "2017-04-10");

        Salary salary = new Salary().getSalary(2);
        System.out.println(salary);

        Salary salario2 = new Salary(1, 1300, "2011-07-07", "2018-10-01");

    }
}

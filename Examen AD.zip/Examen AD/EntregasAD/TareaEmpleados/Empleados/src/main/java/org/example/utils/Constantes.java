package org.example.utils;

public class Constantes {
}

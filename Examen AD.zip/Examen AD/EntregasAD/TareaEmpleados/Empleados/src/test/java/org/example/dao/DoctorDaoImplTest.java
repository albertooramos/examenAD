package org.example.dao;

import junit.framework.TestCase;

public class DoctorDaoImplTest extends TestCase {

    public void testGetDoctors() {
    }
}
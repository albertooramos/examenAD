package org.example.IRepositories;

public interface DoctorRepository {
}
//
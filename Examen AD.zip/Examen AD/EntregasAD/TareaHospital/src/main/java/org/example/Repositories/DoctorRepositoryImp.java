package org.example.Repositories;

import org.example.IRepositories.DoctorRepository;

public class DoctorRepositoryImp implements DoctorRepository {

}
//
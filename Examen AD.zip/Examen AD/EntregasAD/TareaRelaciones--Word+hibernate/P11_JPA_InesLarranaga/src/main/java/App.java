import dao.HashtagDao;
import dao.TweetDao;
import dao.TweetsHashtagsDao;
import dao.UserDao;
import models.Notificacion;
import models.Tweet;
import models.TweetsHashtags;
import models.User;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;

public class App {
    public static void main(String[] args) {

        UserDao userDao = new UserDao();
        String usuarioString="b";
        User user = new User(usuarioString, usuarioString, usuarioString, usuarioString, usuarioString, usuarioString);

        // 1
        /*User userAnianido = userDao.addUser(user);

        System.out.println("-------------AÑADIR USUARIO -----------------");
        System.out.println(userAnianido != null ? "user añadido" : "ERROR user añadido");*/

        //2
        /*boolean cambiarBioUser = userDao.changeBiographyUser(1, "alberto");

        System.out.println("-------------Cambiar bio user -----------------");
        System.out.println(cambiarBioUser ? "bio cambiado" : "ERROR bio cambiado");*/

        /*---3---*/
        /*User userEliminar= userDao.getuser(2);
        boolean eliminarUser = userDao.deleteUser(userEliminar);

        System.out.println("-------------eliminar usuario -----------------");
        System.out.println(eliminarUser ? "usuario eliminado" : "ERROR usuario eliminado");*/

        /*---4---*/

        /*System.out.println("-------------LISTAR Tweet -----------------");
        new TweetDao().listTweetsOrderedByTimeStamp(1).stream().forEach(
                tweet -> System.out.println(tweet.toString()));*/



        /*---5---*/


        /*Tweet tweet= new Tweet();
        tweet.setCreatedAt(new Timestamp(0));
        tweet.setMessage("cccccccccccccc");
        tweet.setUser(new UserDao().getuser(1));
        ArrayList<TweetsHashtags> tweetsHashtags = new ArrayList<>();
        TweetsHashtags tweetsHashtags1= new TweetsHashtags();
        tweetsHashtags1.setHashtag(new HashtagDao().getHashtag(1));
        tweetsHashtags1.setTweet(tweet);
        tweetsHashtags.add(tweetsHashtags1);
        tweet.setTweetsHashtags(tweetsHashtags);


        boolean tweetAnianido= new TweetDao().addTweet(tweet);
        System.out.println("-------------AÑADIR TWEET -----------------");
        System.out.println(tweetAnianido ? "tweet añadido" : "ERROR  tweet añadido");*/

        /*---6---*/

        System.out.println("-------------LISTAR TweetByHashtag -----------------");
        new TweetDao().listTweetsByHashtag(1).stream().forEach(
                tweet -> System.out.println(tweet.toString()));

    }
}

package dao;

import idao.iHashtagDao;
import jakarta.persistence.Query;
import models.Hashtag;
import models.Notificacion;
import models.Tweet;
import models.User;

public class HashtagDao extends Dao<Hashtag> implements iHashtagDao {

    public boolean addHashtag(Hashtag hashtag) {
        try {
            Query query = getEntityManager().createQuery(" select hashtag from Hashtag as hashtag where hashtag.tag=:tag");
            query.setParameter("tag", hashtag.getTag());
            if (query.getResultList().isEmpty()) {
                this.create(hashtag);
            }
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public Hashtag getHashtag(Integer id) {
        return em.find(Hashtag.class, id);
    }

    @Override
    public boolean addHashatg(Hashtag hashtag) {
        try {
            Hashtag hashtag1 = this.create(hashtag);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}

package dao;

import idao.iNotificacionDao;
import idao.iTweetDao;
import models.Notificacion;
import models.Tweet;

public class NotificacionDao extends Dao<Notificacion> implements iNotificacionDao {
    @Override
    public boolean addNotificacion(Notificacion notificacion) {
        try {
            Notificacion notificacionCreada = this.create(notificacion);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}

package dao;

import idao.iTweetDao;
import jakarta.persistence.Query;
import models.Hashtag;
import models.Tweet;
import models.TweetsHashtags;

import java.util.ArrayList;
import java.util.List;

public class TweetDao extends Dao<Tweet> implements iTweetDao {
    @Override
    public List<Tweet> listTweetsOrderedByTimeStamp(Integer user_id) {
        try {
            if (new UserDao().usuarioExiste(user_id)) {
                Query query = getEntityManager().createQuery(" select tweet from Tweet as tweet where tweet.user.id=:id order by tweet.createdAt DESC");
                query.setParameter("id", user_id);
                return query.getResultList();
            }
            return new ArrayList<>();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public boolean addTweet(Tweet tweet) {
        try {
            Tweet tweetCreado = this.create(tweet);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public List<Tweet> listTweetsByHashtag(Integer hashtag_id) {
        try {
            Query query = getEntityManager().createQuery(" select tweet from Tweet as tweet " +
                    " join tweet.tweetsHashtags  tweetsHashtag" +
                    " join  tweetsHashtag.hashtag  hashtags where hashtags.id=:id order by tweet.createdAt DESC");
            query.setParameter("id", hashtag_id);
            return query.getResultList();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new ArrayList<>();
        }
    }
}

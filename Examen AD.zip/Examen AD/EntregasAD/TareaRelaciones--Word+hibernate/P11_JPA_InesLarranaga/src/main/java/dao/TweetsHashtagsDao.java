package dao;

import jakarta.persistence.Query;
import models.Hashtag;
import models.Tweet;
import models.TweetsHashtags;

public class TweetsHashtagsDao extends Dao<TweetsHashtags> {
    public TweetsHashtags getTweetsHashtags(Integer id) {
        return em.find(TweetsHashtags.class, id);
    }

    public boolean addTweetHashtag(TweetsHashtags tweetsHashtags) {
        try {
            this.create(tweetsHashtags);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}

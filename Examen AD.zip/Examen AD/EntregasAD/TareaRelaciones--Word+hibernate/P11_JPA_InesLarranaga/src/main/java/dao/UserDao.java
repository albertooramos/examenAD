package dao;

import idao.iUserDao;
import models.User;

public class UserDao extends Dao<User> implements iUserDao {
    @Override
    public User addUser(User u) {
        try {
            return this.create(u);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }

    @Override
    public boolean changeBiographyUser(Integer user_id, String bioNew) {
        try {
            User user = getuser(user_id);
            if (user != null) {
                user.setBiography(bioNew);
                this.update(user);
                return true;
            }else {
                return false;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteUser(User user) {
        try {
            this.delete(user);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }


    public User getuser(Integer id) {
        return em.find(User.class, id);
    }

    public boolean usuarioExiste(Integer id){
        if (em.find(User.class, id)!=null){
            return true;
        }
        return false;
    }
}

package idao;

import models.Hashtag;
import models.Notificacion;

public interface iHashtagDao {
    public boolean addHashatg(Hashtag hashtag);
}

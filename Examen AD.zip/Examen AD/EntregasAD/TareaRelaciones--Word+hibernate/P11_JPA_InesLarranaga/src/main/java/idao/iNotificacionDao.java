package idao;

import models.Notificacion;
import models.Tweet;

public interface iNotificacionDao {
    public boolean addNotificacion(Notificacion notificacion);
}

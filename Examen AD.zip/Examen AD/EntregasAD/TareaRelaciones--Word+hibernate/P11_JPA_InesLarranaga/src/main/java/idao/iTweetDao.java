package idao;

import models.Tweet;

import java.util.List;

public interface iTweetDao {
    public List<Tweet> listTweetsOrderedByTimeStamp(Integer user_id);

    public boolean addTweet(Tweet tweet);

    public List<Tweet> listTweetsByHashtag (Integer hashtag_id);
}

package idao;

import models.User;

public interface iUserDao {
    public User addUser(User u);

    public boolean changeBiographyUser(Integer user_id, String bioNew);

    public boolean deleteUser(User user);
}

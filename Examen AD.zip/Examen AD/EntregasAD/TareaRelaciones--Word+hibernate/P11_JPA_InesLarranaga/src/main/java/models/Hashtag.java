package models;

import jakarta.persistence.*;

import java.util.Collection;
import java.util.Objects;

@Entity
public class Hashtag {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;

    @Basic
    @Column(name = "tag")
    private String tag;

    @OneToMany(mappedBy = "hashtag")
    private Collection<TweetsHashtags> tweetsHashtagsById;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Collection<TweetsHashtags> getTweetsHashtagsById() {
        return tweetsHashtagsById;
    }

    public void setTweetsHashtagsById(Collection<TweetsHashtags> tweetsHashtagsById) {
        this.tweetsHashtagsById = tweetsHashtagsById;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Hashtag hashtag = (Hashtag) o;
        return id == hashtag.id && Objects.equals(tag, hashtag.tag) && Objects.equals(tweetsHashtagsById, hashtag.tweetsHashtagsById);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, tag, tweetsHashtagsById);
    }

}

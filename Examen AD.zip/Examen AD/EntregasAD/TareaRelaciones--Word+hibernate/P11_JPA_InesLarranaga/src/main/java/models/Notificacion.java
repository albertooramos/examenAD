package models;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
public class Notificacion {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;

    @Basic
    @Column(name = "newAccountsFollowingMe")
    private boolean newAccountsFollowingMe;

    @Basic
    @Column(name = "notFollowedByMe")
    private boolean notFollowedByMe;

    @Basic
    @Column(name = "notFollowingByMe")
    private boolean notFollowingByMe;


    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isNewAccountsFollowingMe() {
        return newAccountsFollowingMe;
    }

    public void setNewAccountsFollowingMe(boolean newAccountsFollowingMe) {
        this.newAccountsFollowingMe = newAccountsFollowingMe;
    }

    public boolean isNotFollowedByMe() {
        return notFollowedByMe;
    }

    public void setNotFollowedByMe(boolean notFollowedByMe) {
        this.notFollowedByMe = notFollowedByMe;
    }

    public boolean isNotFollowingByMe() {
        return notFollowingByMe;
    }

    public void setNotFollowingByMe(boolean notFollowingByMe) {
        this.notFollowingByMe = notFollowingByMe;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Notificacion that = (Notificacion) o;
        return id == that.id && newAccountsFollowingMe == that.newAccountsFollowingMe && notFollowedByMe == that.notFollowedByMe && notFollowingByMe == that.notFollowingByMe && Objects.equals(user, that.user);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, newAccountsFollowingMe, notFollowedByMe, notFollowingByMe, user);
    }
}

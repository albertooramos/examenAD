package models;

import jakarta.persistence.*;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Objects;

@Entity
public class Tweet {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "message")
    private String message;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private User user;

    @OneToMany(mappedBy = "tweet", cascade = CascadeType.ALL)
    private Collection<TweetsHashtags> tweetsHashtags;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Collection<TweetsHashtags> getTweetsHashtags() {
        return tweetsHashtags;
    }

    public void setTweetsHashtags(Collection<TweetsHashtags> tweetsHashtags) {
        this.tweetsHashtags = tweetsHashtags;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tweet tweet = (Tweet) o;
        return id == tweet.id && Objects.equals(createdAt, tweet.createdAt) && Objects.equals(message, tweet.message) && Objects.equals(user, tweet.user);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, createdAt, message, user);
    }

    @Override
    public String toString() {
        return "Tweet{" +
                "id=" + id +
                ", createdAt=" + createdAt +
                ", message='" + message + '\'' +
                ", user=" + user.getName() +
                '}';
    }
}

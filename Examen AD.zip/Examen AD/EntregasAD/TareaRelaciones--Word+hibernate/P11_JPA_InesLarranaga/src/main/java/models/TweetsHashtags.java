package models;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "tweets_hashtags", schema = "P11_examen", catalog = "")
public class TweetsHashtags {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;

    @ManyToOne
    @JoinColumn(name = "tweet_id", referencedColumnName = "id", nullable = false)
    private Tweet tweet;

    @ManyToOne
    @JoinColumn(name = "hashtag_id", referencedColumnName = "id", nullable = false)
    private Hashtag hashtag;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Tweet getTweet() {
        return tweet;
    }

    public void setTweet(Tweet tweet) {
        this.tweet = tweet;
    }

    public Hashtag getHashtag() {
        return hashtag;
    }

    public void setHashtag(Hashtag hashtag) {
        this.hashtag = hashtag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TweetsHashtags that = (TweetsHashtags) o;
        return id == that.id && Objects.equals(tweet, that.tweet) && Objects.equals(hashtag, that.hashtag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, tweet, hashtag);
    }
}

package models;

import jakarta.persistence.*;

import java.util.Collection;
import java.util.Objects;

@Entity
public class User {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;

    @Basic
    @Column(name = "biography")
    private String biography;

    @Basic
    @Column(name = "email")
    private String email;

    @Basic
    @Column(name = "lastName")
    private String lastName;

    @Basic
    @Column(name = "name")
    private String name;

    @Basic
    @Column(name = "password")
    private String password;

    @Basic
    @Column(name = "website")
    private String website;

    @OneToOne(mappedBy = "user", cascade = CascadeType.REMOVE)
    private Notificacion notificacion;

    @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE)
    private Collection<Tweet> tweetById;

    public User( String biography, String email, String lastName, String name, String password, String website) {
        this.biography = biography;
        this.email = email;
        this.lastName = lastName;
        this.name = name;
        this.password = password;
        this.website = website;
    }

    public User() {
    }

    public User(int id, String a, String a1, String a2, String a3, String a4, String a5, int i, int i1) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public Notificacion getNotificacion() {
        return notificacion;
    }

    public void setNotificacion(Notificacion notificacion) {
        this.notificacion = notificacion;
    }

    public Collection<Tweet> getTweetById() {
        return tweetById;
    }

    public void setTweetById(Collection<Tweet> tweetById) {
        this.tweetById = tweetById;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id == user.id && Objects.equals(biography, user.biography) && Objects.equals(email, user.email) && Objects.equals(lastName, user.lastName) && Objects.equals(name, user.name) && Objects.equals(password, user.password) && Objects.equals(website, user.website) && Objects.equals(notificacion, user.notificacion) && Objects.equals(tweetById, user.tweetById);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, biography, email, lastName, name, password, website, notificacion, tweetById);
    }
}

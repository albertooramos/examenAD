package org.jesuitasrioja;

import org.jesuitasrioja.dao.CityDaoImpl;
import org.jesuitasrioja.dao.CountryDaoImpl;
import org.jesuitasrioja.dao.CountrylanguageDaoImpl;
import org.jesuitasrioja.models.Countrylanguage;
import org.jesuitasrioja.utils.DatabaseConnection;

import javax.swing.plaf.synth.SynthOptionPaneUI;


public class App 
{
    public static void main( String[] args ) {
        System.out.println("CITY");
        CityDaoImpl city = new CityDaoImpl();
        System.out.println(city.listaCiudades());
        System.out.println(city.existeCiudad(5));
        System.out.println(city.getCity(125));
        System.out.println(city.listaCiudades("Spain"));
        System.out.println(city.estaCiudadEnPais(15,"ESP"));
        System.out.println(city.cambiarNombreCiudad(45, "Ezcaray"));



        System.out.println("COUNTRY");
        CountryDaoImpl country = new CountryDaoImpl();
        System.out.println(country.listaPaises());
        System.out.println(country.existePais("ESP"));
        System.out.println(country.getCountry("ESP"));



        System.out.println("COUNTRYLANGUAGE");
        CountrylanguageDaoImpl conlan = new CountrylanguageDaoImpl();
        System.out.println(conlan.getAllLanguages());
        System.out.println(conlan.listaIdiomas("ESP"));

    }
}

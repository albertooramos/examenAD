package org.jesuitasrioja.dao;

import org.jesuitasrioja.idao.iCityDao;
import org.jesuitasrioja.models.City;
import org.jesuitasrioja.models.Country;
import org.jesuitasrioja.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

public class CityDaoImpl implements iCityDao {
    CountryDaoImpl countryDaoImpl = new CountryDaoImpl();
    DatabaseConnection con = new  DatabaseConnection();

    @Override
    public Set<City> listaCiudades() {

        String sentenciaSQL= null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado= null;
        Set<City> salida = new HashSet<City>();
        City ciudad;

        try {

            sentenciaSQL = "select * from city order by ID";
            sentencia = connect.prepareStatement(sentenciaSQL);
            resultado = sentencia.executeQuery();
            while (resultado.next()){


                ciudad = new City(resultado.getInt(1),
                        resultado.getString(2),
                        countryDaoImpl.getCountry(resultado.getString(3)),
                        resultado.getString(4),
                        resultado.getInt(5));

                salida.add(ciudad);
            }
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

    @Override
    public Boolean existeCiudad(Integer codigoCiudad) {

        boolean salida = false;
        String sentenciaSQL = null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado = null;

        try {
            sentenciaSQL = "select ID from city where ID = ? ";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setInt(1, codigoCiudad);
            resultado = sentencia.executeQuery();

            salida = resultado.next();

        } catch (SQLException e) {

            e.printStackTrace();
        }
        return salida;
    }

    @Override
    public City getCity(Integer codigoCiudad) {

        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        City ciudad = null;

        try {
            ResultSet resultado= null;

            sentenciaSQL = "select * from city where ID = ?";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setInt(1,codigoCiudad);
            resultado = sentencia.executeQuery();

            resultado.next();
            ciudad= new City(resultado.getInt(1),
                    resultado.getString(2),
                    countryDaoImpl.getCountry(resultado.getString(3)),
                    resultado.getString(4),
                    resultado.getInt(5));

            connect.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ciudad;
    }

    @Override
    public Set<City> listaCiudades(String nombrePais) {

        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado= null;
        Set<City> salida = new HashSet<City>();
        City ciudad;

        try {

            sentenciaSQL = "select * from city where CountryCode = (SELECT Code FROM country WHERE country.Name=?)";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,nombrePais);
            resultado = sentencia.executeQuery();

            while (resultado.next()){

                ciudad= new City(resultado.getInt(1),
                        resultado.getString(2),
                        countryDaoImpl.getCountry(resultado.getString(3)),
                        resultado.getString(4),
                        resultado.getInt(5));

                salida.add(ciudad);

            }

            connect.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;

    }

    @Override
    public Boolean estaCiudadEnPais(Integer codigoCiudad, String codigoPais) {

        boolean salida = false;
        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado= null;
        Country city;
        try {
            sentenciaSQL = "select CountryCode from city where CountryCode= ? and ID = ?;";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,codigoPais);
            sentencia.setInt(2,codigoCiudad);
            resultado = sentencia.executeQuery();

            salida=resultado.next();

        } catch (SQLException e) {

            e.printStackTrace();
        }
        return salida;
    }

    @Override
    public Boolean cambiarNombreCiudad(Integer codigoCiudad, String nuevoNombre) {

        boolean salida = false;
        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        Integer resultado= null;
        City city;
        try {
            sentenciaSQL = "UPDATE city set Name = ? where city.ID = ?";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,nuevoNombre);
            sentencia.setInt(2,codigoCiudad);
            resultado = sentencia.executeUpdate();

            if (resultado != 0){
                salida= true;
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
        return salida;
    }

    @Override
    public void aniadirCiudad(City nuevaCiudad) {

        boolean salida = false;
        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        Integer resultado= null;
        Country city;
        try {
            sentenciaSQL = "Insert Into city  (Name,CountryCode,District,Population) Values (?,?,?,?)";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,nuevaCiudad.getName());
            sentencia.setString(2,nuevaCiudad.getCountryCode().getCode());
            sentencia.setString(3,nuevaCiudad.getDistrict());
            sentencia.setInt(4,nuevaCiudad.getPopulation());

            resultado = sentencia.executeUpdate();

            if (resultado != 0){
                salida= true;
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

    }
}
//
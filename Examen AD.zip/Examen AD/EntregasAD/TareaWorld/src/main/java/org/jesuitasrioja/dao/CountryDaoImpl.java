package org.jesuitasrioja.dao;

import org.jesuitasrioja.idao.iCountryDao;
import org.jesuitasrioja.models.City;
import org.jesuitasrioja.models.Country;
import org.jesuitasrioja.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

public class CountryDaoImpl implements iCountryDao {

    DatabaseConnection con = new  DatabaseConnection();

    @Override
    public Set<Country> listaPaises() {

        String sentenciaSQL= null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado= null;
        Set<Country> salida = new HashSet<Country>();
        Country pais;

        try {

            sentenciaSQL = "select * from country";
            sentencia = connect.prepareStatement(sentenciaSQL);
            resultado = sentencia.executeQuery();
            while (resultado.next()){

                pais = new Country(resultado.getString(1),
                        resultado.getString(2),
                        resultado.getString(3),
                        resultado.getString(4),
                        resultado.getDouble(5),
                        resultado.getInt(6),
                        resultado.getInt(7),
                        resultado.getDouble(8),
                        resultado.getDouble(9),
                        resultado.getDouble(10),
                        resultado.getString(11),
                        resultado.getString(12),
                        resultado.getString(13),
                        resultado.getInt(14),
                        resultado.getString(15));

                salida.add(pais);
            }
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

    @Override
    public Boolean existePais(String codigoPais) {

        boolean salida = false;
        String sentenciaSQL = null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado = null;

        try {
            sentenciaSQL = "select CODE from country where CODE = ? ";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1, codigoPais);
            resultado = sentencia.executeQuery();

            salida = resultado.next();

        } catch (SQLException e) {

            e.printStackTrace();
        }
        return salida;
    }


    @Override
    public Country getCountry(String codigoPais) {

        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        Country pais = null;

        try {
            ResultSet resultado= null;

            sentenciaSQL = "select * from country where code = ?";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,codigoPais);
            resultado = sentencia.executeQuery();

            resultado.next();
            pais= new Country(resultado.getString(1),
                    resultado.getString(2),
                    resultado.getString(3),
                    resultado.getString(4),
                    resultado.getDouble(5),
                    resultado.getInt(6),
                    resultado.getInt(7),
                    resultado.getDouble(8),
                    resultado.getDouble(9),
                    resultado.getDouble(10),
                    resultado.getString(11),
                    resultado.getString(12),
                    resultado.getString(13),
                    resultado.getInt(14),
                    resultado.getString(15));

            connect.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pais;
    }

    @Override
    public Country getPaisDeCiudad(Integer codigoCiudad) {
        return null;
    }

    @Override
    public Boolean aniadirPais(Country nuevaCiudad) {

        boolean salida = false;
        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        Integer resultado= null;

        try {

            sentenciaSQL = "Insert Into country  (Code,Name,Continent,Region,SurfaceArea,IndepYear,Population,LifeExpectancy," +
                    "GNP,GNPOld,LocalName,GovernmentForm,HeadOfState,Capital,Code2) Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,nuevaCiudad.getCode());
            sentencia.setString(2,nuevaCiudad.getName());
            sentencia.setString(3,nuevaCiudad.getContinent());
            sentencia.setString(4,nuevaCiudad.getRegion());
            sentencia.setDouble(5,nuevaCiudad.getSurfaceArea());
            sentencia.setInt(6,nuevaCiudad.getIndepYear());
            sentencia.setInt(7,nuevaCiudad.getPopulation());
            sentencia.setDouble(8,nuevaCiudad.getLifeExpectancy());
            sentencia.setDouble(9,nuevaCiudad.getGNP());
            sentencia.setDouble(10,nuevaCiudad.getGNPOld());
            sentencia.setString(11,nuevaCiudad.getLocalName());
            sentencia.setString(12,nuevaCiudad.getGovernmentForm());
            sentencia.setString(13,nuevaCiudad.getHeadOfState());
            sentencia.setInt(14,nuevaCiudad.getCapital());
            sentencia.setString(15,nuevaCiudad.getCode2());


            resultado = sentencia.executeUpdate();

            if (resultado != 0){
                salida= true;
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
        return salida;

    }
}
//
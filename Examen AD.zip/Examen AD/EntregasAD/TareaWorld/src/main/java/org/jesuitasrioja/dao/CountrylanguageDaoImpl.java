package org.jesuitasrioja.dao;

import org.jesuitasrioja.idao.iCountrylanguageDao;
import org.jesuitasrioja.models.City;
import org.jesuitasrioja.models.Countrylanguage;
import org.jesuitasrioja.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CountrylanguageDaoImpl implements iCountrylanguageDao {

    DatabaseConnection con = new  DatabaseConnection();

    @Override
    public List<Countrylanguage> getAllLanguages() {

        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado= null;
        List<Countrylanguage> salida = new ArrayList<>();


        try{
            sentenciaSQL = "select * from countrylanguage";
            sentencia = connect.prepareStatement(sentenciaSQL);
            resultado = sentencia.executeQuery();

            while (resultado.next()){
                Countrylanguage conlan;
                conlan = new Countrylanguage(resultado.getString(1),
                        resultado.getString(2),
                        resultado.getBoolean(3),
                        resultado.getFloat(4));

                salida.add(conlan);

            }
            connect.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;

    }



    @Override
    public Set<Countrylanguage> listaIdiomas(String codigoPais) {

        String sentenciaSQL=null;
        Connection connect = con.getConnection();
        PreparedStatement sentencia = null;
        ResultSet resultado= null;
        Set<Countrylanguage> salida = new HashSet<>();

        try {

            sentenciaSQL = "select * from countrylanguage where CountryCode = ?";
            sentencia = connect.prepareStatement(sentenciaSQL);
            sentencia.setString(1,codigoPais);
            resultado = sentencia.executeQuery();

            while (resultado.next()){
                Countrylanguage conlan;
                conlan= new Countrylanguage(resultado.getString(1),
                        resultado.getString(2),
                        resultado.getBoolean(3),
                        resultado.getFloat(4));
                salida.add(conlan);
            }
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }
}

//
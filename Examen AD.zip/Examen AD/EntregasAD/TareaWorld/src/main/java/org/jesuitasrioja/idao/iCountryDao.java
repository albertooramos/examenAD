package org.jesuitasrioja.idao;

import org.jesuitasrioja.models.Country;

import java.util.Set;

public interface iCountryDao {

    public Set<Country> listaPaises();
    public Boolean existePais(String codigoPais);
    public Country getCountry(String codigoPais);
    public Country getPaisDeCiudad(Integer codigoCiudad);
    public Boolean aniadirPais(Country nuevaCiudad);


}
//
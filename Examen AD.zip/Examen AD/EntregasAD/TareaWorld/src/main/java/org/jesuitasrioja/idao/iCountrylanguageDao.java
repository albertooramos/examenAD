package org.jesuitasrioja.idao;

import org.jesuitasrioja.models.Countrylanguage;

import java.util.List;
import java.util.Set;

public interface iCountrylanguageDao {

    public List<Countrylanguage> getAllLanguages();
    public Set<Countrylanguage> listaIdiomas(String codigoPais);

}
//
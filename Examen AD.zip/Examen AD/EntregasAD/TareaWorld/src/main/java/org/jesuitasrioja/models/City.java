package org.jesuitasrioja.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class City {

    private int ID;
    private String Name;
    private Country CountryCode;
    private String District;
    private int Population;

}
//
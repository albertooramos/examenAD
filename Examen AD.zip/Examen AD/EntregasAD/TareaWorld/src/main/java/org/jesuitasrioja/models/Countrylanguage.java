package org.jesuitasrioja.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Countrylanguage {

    private String CountryCode;
    private String Language;
    private boolean IsOfficial;
    private float Percentage;

}
//
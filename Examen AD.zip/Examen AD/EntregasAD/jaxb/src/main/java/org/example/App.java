package org.example;

import org.example.entidades.Enemigo;
import org.example.entidades.Enemigo2;
import org.example.entidades.listaEnemigos;
import org.example.entidades.listaEnemigos2;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        Enemigo2 batman = new Enemigo2("batman", "100", "15");
        Enemigo2 superman = new Enemigo2("superman", "200", "150");
        Enemigo2 spiderman = new Enemigo2("spiderman", "10", "5");

        ArrayList<Enemigo2> enemigos = new ArrayList<>();
        enemigos.add(batman);
        enemigos.add(superman);
        enemigos.add(spiderman);
        listaEnemigos2 lista = new listaEnemigos2(enemigos);

        try {
            JAXBContext contexto = JAXBContext.newInstance(listaEnemigos2.class);
            Marshaller serializador = contexto.createMarshaller();
            //serializador.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
            serializador.marshal(lista, new File("enemigos.xml"));


        } catch (JAXBException e) {
            e.printStackTrace();
        }

    }
}

package org.example.entidades;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Enemigo {
    String nombre;
    String vida;
    String poder;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getVida() {
        return vida;
    }

    public void setVida(String vida) {
        this.vida = vida;
    }

    public String getPoder() {
        return poder;
    }

    public void setPoder(String poder) {
        this.poder = poder;
    }

    public Enemigo() {
    }

    public Enemigo(String nombre, String vida, String poder) {
        this.nombre = nombre;
        this.vida = vida;
        this.poder = poder;
    }

    @Override
    public String toString() {
        return "Enemigo{" +
                "nombre='" + nombre + '\'' +
                ", vida='" + vida + '\'' +
                ", poder='" + poder + '\'' +
                '}';
    }
}



package org.example.entidades;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
public class listaEnemigos {

    private List<Enemigo> enemigos;

    public listaEnemigos(List<Enemigo> enemigos) {
        this.enemigos = enemigos;
    }

    public listaEnemigos() {
    }

    public List<Enemigo> getEnemigos() {
        return enemigos;
    }

    public void setEnemigos(List<Enemigo> enemigos) {
        this.enemigos = enemigos;
    }

    @Override
    public String toString() {
        return "listaEnemigos{" +
                "enemigos=" + enemigos +
                '}';
    }
}

package org.example.entidades;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
public class listaEnemigos2 {

    private List<Enemigo2> enemigos;

    public listaEnemigos2(List<Enemigo2> enemigos) {
        this.enemigos = enemigos;
    }

    public listaEnemigos2() {
    }

    public List<Enemigo2> getEnemigos() {
        return enemigos;
    }

    public void setEnemigos(List<Enemigo2> enemigos) {
        this.enemigos = enemigos;
    }

    @Override
    public String toString() {
        return "listaEnemigos2{" +
                "enemigos=" + enemigos +
                '}';
    }
}

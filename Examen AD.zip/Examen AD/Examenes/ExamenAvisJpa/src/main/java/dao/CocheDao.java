package dao;

import java.util.Date;

public class CocheDao {

}

package model;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Objects;

@Entity
public class Reservas {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "user_id")
    private int userId;
    @Basic
    @Column(name = "coche_id")
    private int cocheId;
    @Basic
    @Column(name = "fecha_inicio")
    private Date fechaInicio;
    @Basic
    @Column(name = "fecha_fin")
    private Date fechaFin;
    @Basic
    @Column(name = "precio_total")
    private double precioTotal;
    @Basic
    @Column(name = "estado")
    private Object estado;
    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private Users usersByUserId;
    @OneToMany(mappedBy = "reservasByReservaId")
    private Collection<ReservasExtras> reservasExtrasById;
    @ManyToOne
    @JoinColumn(name = "coche_id", referencedColumnName = "id", nullable = false)
    private Coches cochesByCocheId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getCocheId() {
        return cocheId;
    }

    public void setCocheId(int cocheId) {
        this.cocheId = cocheId;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }

    public Object getEstado() {
        return estado;
    }

    public void setEstado(Object estado) {
        this.estado = estado;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservas reservas = (Reservas) o;
        return id == reservas.id && userId == reservas.userId && cocheId == reservas.cocheId && Double.compare(reservas.precioTotal, precioTotal) == 0 && Objects.equals(fechaInicio, reservas.fechaInicio) && Objects.equals(fechaFin, reservas.fechaFin) && Objects.equals(estado, reservas.estado) && Objects.equals(updatedAt, reservas.updatedAt) && Objects.equals(createdAt, reservas.createdAt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, userId, cocheId, fechaInicio, fechaFin, precioTotal, estado, updatedAt, createdAt);
    }

    public Users getUsersByUserId() {
        return usersByUserId;
    }

    public void setUsersByUserId(Users usersByUserId) {
        this.usersByUserId = usersByUserId;
    }

    public Collection<ReservasExtras> getReservasExtrasById() {
        return reservasExtrasById;
    }

    public void setReservasExtrasById(Collection<ReservasExtras> reservasExtrasById) {
        this.reservasExtrasById = reservasExtrasById;
    }

    public Coches getCochesByCocheId() {
        return cochesByCocheId;
    }

    public void setCochesByCocheId(Coches cochesByCocheId) {
        this.cochesByCocheId = cochesByCocheId;
    }
}

package model;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "reservas_extras", schema = "AD_avis", catalog = "")
public class ReservasExtras {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "reserva_id")
    private int reservaId;
    @Basic
    @Column(name = "extra_id")
    private int extraId;
    @ManyToOne
    @JoinColumn(name = "reserva_id", referencedColumnName = "id", nullable = false)
    private Reservas reservasByReservaId;
    @ManyToOne
    @JoinColumn(name = "extra_id", referencedColumnName = "id", nullable = false)
    private Extras extrasByExtraId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReservaId() {
        return reservaId;
    }

    public void setReservaId(int reservaId) {
        this.reservaId = reservaId;
    }

    public int getExtraId() {
        return extraId;
    }

    public void setExtraId(int extraId) {
        this.extraId = extraId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReservasExtras that = (ReservasExtras) o;
        return id == that.id && reservaId == that.reservaId && extraId == that.extraId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, reservaId, extraId);
    }

    public Reservas getReservasByReservaId() {
        return reservasByReservaId;
    }

    public void setReservasByReservaId(Reservas reservasByReservaId) {
        this.reservasByReservaId = reservasByReservaId;
    }

    public Extras getExtrasByExtraId() {
        return extrasByExtraId;
    }

    public void setExtrasByExtraId(Extras extrasByExtraId) {
        this.extrasByExtraId = extrasByExtraId;
    }
}

package example.persistencia;

public enum Estado {
    PAGADO, NOPAGADO
}

package example.persistencia;

public class Usuario {
    public int id;
    public String nombre;
    public String apellido;
}

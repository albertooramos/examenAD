package dao;

import models.Categoria;

public class CategoriasDao extends Dao<Categoria> {
    public Categoria getCategoria(Integer id) {
        return em.find(Categoria.class, id);
    }

}

package dao;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

abstract class Dao<T> {
    EntityManager em = Persistence
            .createEntityManagerFactory("default")
            .createEntityManager();
    public EntityManager getEntityManager() {
        return this.em;
    }
    public T create(T t) {
//        checkTransaction();
        em.persist(t);
        em.flush();
        em.refresh(t);
        return t;
    }
    public T update(T t) {
        checkTransaction();
        return (T) em.merge(t);
    }
    public void delete(T t) {
        checkTransaction();
        t = em.merge(t);
        em.remove(t);
    }
    private void checkTransaction() {
        if (!em.getTransaction().isActive()) throw new
                RuntimeException("Transacción inactiva");
    }

}
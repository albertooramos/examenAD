package dao;

import models.Pedido;

import java.util.ArrayList;
import java.util.List;

public class PedidosDao extends Dao<Pedido> {
    public Pedido getPedido(Integer id) {
        return em.find(Pedido.class, id);
    }

    public List<Pedido> listarPedidosUsuario(Integer userId) {
        return new ArrayList<>();
        //return UsuariosDao.getUsuario(userId).getPedidos();
    }
}

package dao;

import models.Categoria;
import models.Pedido;
import models.Producto;

import java.util.List;

public class ProductosDao extends Dao<Producto>{

    public boolean aniadirProducto(Producto producto) {
        try {
            this.create(producto);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public List<Producto> listarProductosCategoria(Integer categoriaId) {
        Categoria categoria = new CategoriasDao().getCategoria(categoriaId);
        return categoria.getProductos();
    }
}

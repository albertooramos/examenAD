package idao;

public interface iPedidosDao {
}

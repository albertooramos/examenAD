package com.jesuitas.Proyecto.Barros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoBarrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoBarrosApplication.class, args);
	}

}

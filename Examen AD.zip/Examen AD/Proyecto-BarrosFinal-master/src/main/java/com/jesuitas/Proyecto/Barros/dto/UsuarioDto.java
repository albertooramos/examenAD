package com.jesuitas.Proyecto.Barros.dto;

import lombok.Data;

@Data
public class UsuarioDto {
    private Integer idUsuario;
    private String nombreUsuario;
    private String contrasenia;
}

package com.jesuitas.Proyecto.Barros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoBarrosApplicationTests {

	@Test
	void contextLoads() {
	}

}

import persistencia.PersistenciaJDBC;
import persistencia.User;

import javax.xml.parsers.ParserConfigurationException;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) throws ParserConfigurationException {
        ////------1-----

        /*boolean actualiazado = new PersistenciaJDBC().changeBiographyUser(1,"alvaro");
        System.out.println(actualiazado? "actualiazado ok" : "error");*/

        ////------2-----

        List<User> users = new PersistenciaJDBC().listUsers();
        if (users == null) {
            System.out.println("No se ha obtenido ningun usuario");
        } else {
            users.forEach(
                    user -> System.out.println(user.toString()));
            PersistenciaJDBC.crearArchivoXml(users);
        }
    }
}

package persistencia;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Hashtag {
    public int id;
    public String tag;

}

package persistencia;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Notificacion {
    public int id;
    public boolean newAccountsFollowingMe;
    public String notFollowedByMe;
    public int notFollowingByMe;
}

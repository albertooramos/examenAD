package persistencia;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaJDBC {

    private String url;
    private String usr;
    private String pass;

    public PersistenciaJDBC() {
        url = "jdbc:mysql://localhost:3307/P11_examen";
        usr = "root";
        pass = "root";
    }

    public boolean changeBiographyUser(Integer user_id, String bioNew) {
        boolean result = false;
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, usr, pass);
            conn.setAutoCommit(false);

            if (!this.existeUser(user_id)) {
                return false;
            }

            PreparedStatement ps = conn.prepareStatement("update user set biography=? where id =?");
            ps.setString(1, bioNew);
            ps.setInt(2, user_id);
            ps.executeUpdate();
            conn.commit();
            ps.close();
            conn.close();
            result = true;

        } catch (SQLException e) {
            try {
                //(3) si existe algún error hacer rollback
                conn.rollback();
                System.err.println("Se ha realizado el rollback en changeBiography");
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }


    private boolean existeUser(int id) {
        Boolean existe = false;

        Connection conn = null;

        try {
            conn = DriverManager.getConnection(url, usr, pass);

            PreparedStatement ps = conn.prepareStatement("select * from user where id=?");
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            existe = rs.next();

            rs.close();
            ps.close();
            conn.close();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        return existe;
    }

    public List<User> listUsers() {
        boolean result = false;
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, usr, pass);
            conn.setAutoCommit(false);


            PreparedStatement ps = conn.prepareStatement("select * from user");
            ResultSet rs = ps.executeQuery();
            ArrayList<User> users = new ArrayList<>();
            while (rs.next()) {
                User user = new User(rs.getInt("id"), rs.getString("biography"), rs.getString("email"),
                        rs.getString("lastName"), rs.getString("name"), rs.getString("password"),
                        rs.getString("website"));
                users.add(user);
            }
            ps.close();
            conn.close();
            return users;

        } catch (SQLException e) {
            try {
                //(3) si existe algún error hacer rollback
                conn.rollback();
                System.err.println("Se ha realizado el rollback en ListUser");
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } finally {
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    public static void crearArchivoXml(List<User> users) throws ParserConfigurationException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

        DOMImplementation dImplementation = dBuilder.getDOMImplementation();
        Document doc = dImplementation.createDocument(null, "List", null);

        users.forEach(user -> {
            Element elUser = doc.createElement("user");
            doc.getDocumentElement().appendChild(elUser);

            Element elId = doc.createElement("id");
            elId.appendChild(doc.createTextNode(String.valueOf(user.id)));
            elUser.appendChild(elId);

            Element elBiography = doc.createElement("biography");
            elBiography.appendChild(doc.createTextNode(user.biography));
            elUser.appendChild(elBiography);
        });

        try {
            // obtengo transformer y DOMSource.
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            // almacenamento en un fichero de texto
            StreamResult result = new StreamResult(new File("usuarios.xml"));
            transformer.transform(source, result);
            // devolución por pantalla
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);
        } catch (TransformerFactoryConfigurationError | TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}

package persistencia;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TweetsHashtgas {
    public int id;
    public int tweet_id;
    public int hashtag_id;
}

package persistencia;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class User implements Serializable {
    public int id;
    public String biography;
    public String email;
    public String lastname;
    public String name;
    public String password;
    public String website;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", biography='" + biography + '\'' +
                ", email='" + email + '\'' +
                ", lastname='" + lastname + '\'' +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", website='" + website + '\'' +
                '}';
    }
}
